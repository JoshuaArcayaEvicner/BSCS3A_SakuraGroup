

Vue.component('component-one', {
    template: '<div>Component One</div>'
  });
  
  Vue.component('component-two', {
    template: '<div>Component Two</div>'
  });
  
  Vue.component('component-three', {
    template: '<div>Component Three</div>'
  });
  
  Vue.component('component-four', {
    template: '<div>Component Four</div>'
  });
  
  Vue.component('component-five', {
    template: '<div>Component Five</div>'
  });
  
  Vue.component('component-six', {
    template: '<div>Component Six</div>'
  });
  
  Vue.component('component-seven', {
    template: '<div>Component Seven</div>'
  });
  
  Vue.component('component-eight', {
    template: '<div>Component Eight</div>'
  });
  
  Vue.component('component-nine', {
    template: '<div>Component Nine</div>'
  });
  
  Vue.component('component-ten', {
    template: '<div>Component Ten</div>'
  });
  
  Vue.component('component-eleven', {
    template: '<div>Component Eleven</div>'
  });
  
  Vue.component('component-twelve', {
    template: '<div>Component Twelve</div>'
  });
  
  new Vue({
    el: '#app'
  });
  